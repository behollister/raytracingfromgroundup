/////////////////////////////////////////////////////////////////////////////
// Name:        wx/dirctrl.h
// Purpose:     Directory control base header
// Author:      Julian Smart
// Modified by:
// Created:
// Copyright:   (c) Julian Smart
// RCS-ID:      $Id: dirctrl.h,v 1.2 2005/05/04 18:51:57 JS Exp $
// Licence:     wxWindows Licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_DIRCTRL_H_BASE_
#define _WX_DIRCTRL_H_BASE_

#include "wx/generic/dirctrlg.h"

#endif
    // _WX_DIRCTRL_H_BASE_
