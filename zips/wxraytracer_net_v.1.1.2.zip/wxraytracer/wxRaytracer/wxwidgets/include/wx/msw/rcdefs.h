///////////////////////////////////////////////////////////////////////////////
// Name:        wx/msw/rcdefs.h
// Purpose:     Fallback for the generated rcdefs.h under the lib directory
// Author:      Mike Wetherell
// RCS-ID:      $Id: rcdefs.h,v 1.1 2005/11/08 22:49:46 MW Exp $
// Copyright:   (c) 2005 Mike Wetherell
// Licence:     wxWindows licence
///////////////////////////////////////////////////////////////////////////////

#ifndef _WX_RCDEFS_H
#define _WX_RCDEFS_H

#define WX_CPU_X86

#endif
